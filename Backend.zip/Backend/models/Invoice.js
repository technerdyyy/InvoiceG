const mongoose = require("mongoose");

const invoiceSchema = new mongoose.Schema({
  customerName: String,
  customerEmail: String,
  items: [
    {
      description: String,
      quantity: Number,
      price: Number,
    },
  ],
  totalAmount: Number,
  invoiceDate: {
    type: Date,
    default: Date.now,
  },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
});

module.exports = mongoose.model("Invoice", invoiceSchema);
